doit = require('./index.js');

console.log(doit.list());

console.log(doit('ApiDemos-debug'));
console.log(doit('ContactManager'));
console.log(doit('HelloGappium'));
console.log(doit('HelloGappium-debug'));
